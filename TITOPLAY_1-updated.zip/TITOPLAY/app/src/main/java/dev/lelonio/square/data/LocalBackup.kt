package dev.lelonio.square.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * The app's own settings and what it keeps for the listener, in one file they
 * can keep: for a new phone, or after a clean install.
 *
 * Only an explicit list of what the listener has chosen or collected goes in.
 * Anything that signs the app in to an account (the Spotify and YouTube tokens,
 * the web API keys, the ListenBrainz token) is deliberately not on it, so a
 * backup file is safe to put in a cloud drive: it cannot be used to act as
 * them. Accounts are signed in to again after a restore.
 *
 * What is restored is written to the stores' own files, which the app reads
 * when it starts: it has to be closed and opened again to take effect.
 */
object LocalBackup {

    private const val APP = "TITOPLAY"
    private const val VERSION = 1

    /** The preference files that are the listener's choices and collections, and nothing else. */
    private val FILES = listOf(
        "square_preferences",
        "square_glass",
        "square_language",
        "square_quality",
        "square_downloads",
        "square_crossfade",
        "square_effect_presets",
        "equalizer",
        "spot_audio_effects",
        "square_effect_quality",
        "square_library_view",
        "square_pinned_playlists",
        "square_playlist_order",
        "local_likes",
        "square_listening",
    )

    /** Writes the backup to [uri]; false if it could not be written. */
    suspend fun export(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val files = JSONObject()
            for (name in FILES) {
                val all = context.getSharedPreferences(name, Context.MODE_PRIVATE).all
                if (all.isEmpty()) continue
                val values = JSONObject()
                for ((key, value) in all) {
                    encode(value)?.let { values.put(key, it) }
                }
                files.put(name, values)
            }
            val root = JSONObject()
                .put("app", APP)
                .put("version", VERSION)
                .put("createdAt", System.currentTimeMillis())
                .put("files", files)
            val out = context.contentResolver.openOutputStream(uri, "wt") ?: error("no output")
            out.use { it.write(root.toString().toByteArray(Charsets.UTF_8)) }
            true
        }.getOrDefault(false)
    }

    /** Reads a backup from [uri] and puts it back; false if the file is not one of ours. */
    suspend fun restore(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val input = context.contentResolver.openInputStream(uri) ?: error("no input")
            val text = input.use { it.readBytes().toString(Charsets.UTF_8) }
            val root = JSONObject(text)
            require(root.optString("app") == APP && root.optInt("version") in 1..VERSION)
            val files = root.getJSONObject("files")
            for (name in FILES) {
                val values = files.optJSONObject(name) ?: continue
                val edit = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
                for (key in values.keys()) {
                    decode(edit, key, values.getJSONObject(key))
                }
                edit.commit()
            }
            true
        }.getOrDefault(false)
    }

    private fun encode(value: Any?): JSONObject? = when (value) {
        is String -> JSONObject().put("t", "s").put("v", value)
        is Boolean -> JSONObject().put("t", "b").put("v", value)
        is Int -> JSONObject().put("t", "i").put("v", value)
        is Long -> JSONObject().put("t", "l").put("v", value)
        is Float -> JSONObject().put("t", "f").put("v", value.toDouble())
        is Set<*> -> JSONObject().put("t", "set").put("v", JSONArray(value.filterIsInstance<String>()))
        else -> null
    }

    private fun decode(edit: android.content.SharedPreferences.Editor, key: String, entry: JSONObject) {
        when (entry.getString("t")) {
            "s" -> edit.putString(key, entry.getString("v"))
            "b" -> edit.putBoolean(key, entry.getBoolean("v"))
            "i" -> edit.putInt(key, entry.getInt("v"))
            "l" -> edit.putLong(key, entry.getLong("v"))
            "f" -> edit.putFloat(key, entry.getDouble("v").toFloat())
            "set" -> {
                val array = entry.getJSONArray("v")
                edit.putStringSet(key, (0 until array.length()).map { array.getString(it) }.toSet())
            }
        }
    }
}
