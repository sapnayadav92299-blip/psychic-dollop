package dev.lelonio.square.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sends what is listened to to ListenBrainz, the open listening history, for
 * the listener who has given the app their user token.
 *
 * A play is sent once it counts: the listening recorder's own rule, half the
 * song or four minutes. Nothing is lost to a bad connection: a listen is kept
 * on the phone until ListenBrainz has taken it, and what is waiting is sent
 * with the next one. Nothing at all happens until a token is saved.
 */
class ListenBrainz(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
    private val http = OkHttpClient()
    private val lock = Mutex()

    /** Plays already filed, so the recorder's repeated look at one play is one listen. */
    private val seen = LinkedHashSet<String>()

    private val _token = MutableStateFlow(prefs.getString(KEY_TOKEN, "").orEmpty())

    /** The user token, or empty while not connected. */
    val token: StateFlow<String> = _token.asStateFlow()

    private val _pending = MutableStateFlow(readQueue().length())

    /** How many listens are waiting to be sent. */
    val pending: StateFlow<Int> = _pending.asStateFlow()

    private val _rejected = MutableStateFlow(false)

    /** Whether ListenBrainz refused the token the last time it was tried. */
    val rejected: StateFlow<Boolean> = _rejected.asStateFlow()

    fun setToken(value: String) {
        val clean = value.trim()
        _token.value = clean
        _rejected.value = false
        prefs.edit().putString(KEY_TOKEN, clean).apply()
        // Disconnecting forgets what was waiting: it was for that account.
        if (clean.isEmpty()) writeQueue(JSONArray())
    }

    /** Files a play that counts, and sends what is waiting. */
    suspend fun submit(event: ListeningEvent) {
        if (_token.value.isEmpty()) return
        val track = event.track
        if (track.name.isBlank() || track.artist.isBlank()) return
        val fresh = synchronized(seen) {
            val added = seen.add(event.id)
            if (seen.size > MAX_SEEN) seen.remove(seen.first())
            added
        }
        if (!fresh) return
        lock.withLock {
            val queue = readQueue()
            queue.put(listen(event))
            writeQueue(queue)
        }
        flush()
    }

    /** Sends what is waiting, oldest first, in batches; stops at the first thing that cannot be sent. */
    suspend fun flush() {
        withContext(Dispatchers.IO) {
            lock.withLock {
                val token = _token.value
                if (token.isEmpty()) return@withLock
                var queue = readQueue()
                while (queue.length() > 0) {
                    val count = minOf(queue.length(), BATCH)
                    val batch = JSONArray()
                    for (index in 0 until count) batch.put(queue.get(index))
                    when (post(token, batch)) {
                        Outcome.SENT, Outcome.REFUSED -> {
                            queue = withoutFirst(queue, count)
                            writeQueue(queue)
                            _rejected.value = false
                        }
                        Outcome.BAD_TOKEN -> {
                            _rejected.value = true
                            return@withLock
                        }
                        Outcome.LATER -> return@withLock
                    }
                }
            }
        }
    }

    private enum class Outcome { SENT, REFUSED, BAD_TOKEN, LATER }

    private fun post(token: String, listens: JSONArray): Outcome {
        val type = if (listens.length() == 1) "single" else "import"
        val body = JSONObject().put("listen_type", type).put("payload", listens).toString()
        return runCatching {
            val request = Request.Builder()
                .url(SUBMIT_URL)
                .header("Authorization", "Token $token")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(request).execute().use { response ->
                when {
                    response.isSuccessful -> Outcome.SENT
                    response.code == 401 -> Outcome.BAD_TOKEN
                    // Too many requests: the same listens, later.
                    response.code == 429 -> Outcome.LATER
                    // The rest of the 4xx: ListenBrainz does not want these
                    // listens as they are, and sending them again will not
                    // change that, so they must not block the ones behind.
                    response.code in 400..499 -> Outcome.REFUSED
                    else -> Outcome.LATER
                }
            }
        }.getOrDefault(Outcome.LATER)
    }

    private fun listen(event: ListeningEvent): JSONObject {
        val track = event.track
        val info = JSONObject()
            .put("media_player", "TITOPLAY")
            .put("submission_client", "TITOPLAY")
            .put("duration_ms", track.durationMs)
        if (track.uri.startsWith("spotify:track:")) {
            info.put("spotify_id", "https://open.spotify.com/track/" + track.uri.removePrefix("spotify:track:"))
        }
        val metadata = JSONObject()
            .put("artist_name", track.artist)
            .put("track_name", track.name)
        if (track.album.isNotBlank()) metadata.put("release_name", track.album)
        metadata.put("additional_info", info)
        return JSONObject()
            .put("listened_at", event.startedAt / 1000)
            .put("track_metadata", metadata)
    }

    private fun withoutFirst(queue: JSONArray, count: Int): JSONArray {
        val rest = JSONArray()
        for (index in count until queue.length()) rest.put(queue.get(index))
        return rest
    }

    private fun readQueue(): JSONArray =
        runCatching { JSONArray(prefs.getString(KEY_QUEUE, "[]")) }.getOrDefault(JSONArray())

    private fun writeQueue(queue: JSONArray) {
        prefs.edit().putString(KEY_QUEUE, queue.toString()).apply()
        _pending.value = queue.length()
    }

    companion object {
        private const val FILE_NAME = "square_listenbrainz"
        private const val KEY_TOKEN = "token"
        private const val KEY_QUEUE = "queue"
        private const val SUBMIT_URL = "https://api.listenbrainz.org/1/submit-listens"
        private const val BATCH = 50
        private const val MAX_SEEN = 300
    }
}
