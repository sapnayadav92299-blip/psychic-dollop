package dev.lelonio.square.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * A running light round a pill: the glow a voice assistant draws round the
 * edge of the screen while it listens, put round one control.
 *
 * Six colours, blue, violet, coral, amber, green and teal, flow once round the
 * rim every [periodMillis] and meet again where they began, so no two parts of
 * the edge have the same colour and every part keeps changing it. The light is
 * in two places: a soft glow *outside* the pill, which is the part that reads
 * as light, and a bright hairline on its edge, which is the part that reads as
 * sharp. Inside the pill nothing is drawn: it is glass, and stays glass.
 *
 * Costs a frame of drawing, every frame, only while [active]; where it is put
 * to work, that is only while the music plays.
 *
 * The colours are placed along the edge by where each part of it is, not by its
 * angle from the middle. On a pill that is much wider than tall the two are not
 * the same, and by angle alone the whole of each long side would be one colour.
 */
fun Modifier.aurora(
    active: Boolean,
    periodMillis: Int = 2200,
    hairline: Dp = 2.dp,
): Modifier = composed {
    if (!active) {
        this
    } else {
        val transition = rememberInfiniteTransition(label = "aurora")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(periodMillis, easing = LinearEasing)),
            label = "auroraPhase",
        )
        this.drawWithContent {
            val w = size.width
            val h = size.height
            if (w <= 0f || h <= 0f) {
                drawContent()
                return@drawWithContent
            }
            val r = h / 2f
            val brush = ShaderBrush(
                android.graphics.SweepGradient(
                    w / 2f,
                    h / 2f,
                    stopColors(phase),
                    stopPositions(w, h),
                ),
            )
            // Breathing a little, so the light is alive and not a fixed pattern
            // sliding round.
            val breath = 0.86f + 0.14f * sin(phase * 2f * PI.toFloat() * 2f)

            // Outside only: the pill's own shape is cut out of what is drawn.
            val pill = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(r, r))) }
            clipPath(pill, ClipOp.Difference) {
                for ((grow, width, alpha) in GLOW) {
                    val g = grow.dp.toPx()
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(-g, -g),
                        size = Size(w + 2f * g, h + 2f * g),
                        cornerRadius = CornerRadius(r + g, r + g),
                        style = Stroke(width.dp.toPx()),
                        alpha = alpha * breath,
                    )
                }
            }

            drawContent()

            val edge = hairline.toPx()
            drawRoundRect(
                brush = brush,
                topLeft = Offset(edge / 2f, edge / 2f),
                size = Size(w - edge, h - edge),
                cornerRadius = CornerRadius(r - edge / 2f, r - edge / 2f),
                style = Stroke(edge),
                alpha = 0.95f * breath,
            )
        }
    }
}

/** Glow layers, outermost first: how far out from the edge, how thick, how strong. */
private val GLOW = listOf(
    Triple(6f, 18f, 0.14f),
    Triple(3.5f, 11f, 0.26f),
    Triple(1.5f, 6f, 0.46f),
)

private val PALETTE = listOf(
    Color(0xFF4285F4),
    Color(0xFF9B72CB),
    Color(0xFFD96570),
    Color(0xFFFBBC05),
    Color(0xFF34A853),
    Color(0xFF1AD6C6),
)

/** The colour at [t] round the loop, 0 to 1, easing from one stop of the palette to the next. */
private fun colorAt(t: Float): Color {
    val wrapped = t - floor(t)
    val scaled = wrapped * PALETTE.size
    val index = floor(scaled).toInt() % PALETTE.size
    val into = scaled - floor(scaled)
    val eased = into * into * (3f - 2f * into)
    return lerp(PALETTE[index], PALETTE[(index + 1) % PALETTE.size], eased)
}

private const val STOPS = 30

/** The colours of the sweep, flowing clockwise as [phase] grows; the last is the first, closing the loop. */
private fun stopColors(phase: Float): IntArray =
    IntArray(STOPS + 1) { i -> colorAt(i.toFloat() / STOPS - phase).toArgb() }

/**
 * Where each of those colours sits in the sweep: the angle, from the middle,
 * of the point that is that far round the edge of a pill [w] by [h], starting
 * at the middle of its right end and going clockwise.
 */
private fun stopPositions(w: Float, h: Float): FloatArray {
    val r = h / 2f
    val straight = (w - h).coerceAtLeast(0f)
    val perimeter = 2f * straight + 2f * PI.toFloat() * r
    val cx = w / 2f
    val cy = h / 2f
    return FloatArray(STOPS + 1) { i ->
        if (i == 0) return@FloatArray 0f
        if (i == STOPS) return@FloatArray 1f
        var s = i.toFloat() / STOPS * perimeter
        val quarter = PI.toFloat() * r / 2f
        val (x, y) = when {
            // Lower half of the right end: from straight ahead, round to the bottom.
            s < quarter -> {
                val a = s / r
                Pair(cx + straight / 2f + r * cos(a), cy + r * sin(a))
            }
            // Along the bottom, right to left.
            s < quarter + straight -> {
                s -= quarter
                Pair(cx + straight / 2f - s, cy + r)
            }
            // The whole of the left end.
            s < quarter + straight + PI.toFloat() * r -> {
                s -= quarter + straight
                val a = PI.toFloat() / 2f + s / r
                Pair(cx - straight / 2f + r * cos(a), cy + r * sin(a))
            }
            // Along the top, left to right.
            s < quarter + 2f * straight + PI.toFloat() * r -> {
                s -= quarter + straight + PI.toFloat() * r
                Pair(cx - straight / 2f + s, cy - r)
            }
            // Upper half of the right end, back to the start.
            else -> {
                s -= quarter + 2f * straight + PI.toFloat() * r
                val a = 3f * PI.toFloat() / 2f + s / r
                Pair(cx + straight / 2f + r * cos(a), cy + r * sin(a))
            }
        }
        var angle = atan2(y - cy, x - cx)
        if (angle < 0f) angle += 2f * PI.toFloat()
        (angle / (2f * PI.toFloat())).coerceIn(0f, 1f)
    }
}
