package dev.lelonio.square.playback

import androidx.compose.runtime.mutableFloatStateOf
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Left and right volume, one each, for headphones and earbuds.
 *
 * A level is a share of the system volume, 0 to 1, and counts only while the
 * music is going to headphones (a cable, Bluetooth or USB): on the phone's
 * speaker both sides always play at full share, and unplugging puts both
 * back, so a lowered side can never follow the music to a speaker.
 */
object ChannelBalance {

    val left = mutableFloatStateOf(1f)
    val right = mutableFloatStateOf(1f)

    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    init {
        AudioRoute.onChange { output ->
            if (!isHeadphones(output.kind)) {
                left.floatValue = 1f
                right.floatValue = 1f
            }
            changed()
        }
    }

    fun isHeadphones(kind: AudioRoute.Kind): Boolean =
        kind == AudioRoute.Kind.WIRED || kind == AudioRoute.Kind.BLUETOOTH || kind == AudioRoute.Kind.USB

    fun leftGain(): Float =
        if (isHeadphones(AudioRoute.current.value.kind)) left.floatValue.coerceIn(0f, 1f) else 1f

    fun rightGain(): Float =
        if (isHeadphones(AudioRoute.current.value.kind)) right.floatValue.coerceIn(0f, 1f) else 1f

    /** True while both sides are at full share: the usual case, in which this object changes nothing. */
    fun isNeutral(): Boolean = leftGain() >= 0.999f && rightGain() >= 0.999f

    fun set(leftLevel: Float?, rightLevel: Float?) {
        if (leftLevel != null) left.floatValue = leftLevel.coerceIn(0f, 1f)
        if (rightLevel != null) right.floatValue = rightLevel.coerceIn(0f, 1f)
        changed()
    }

    /** Called whenever a level or the output changes, on whatever thread did it. */
    fun listen(listener: () -> Unit) {
        listeners += listener
    }

    private fun changed() {
        listeners.forEach { runCatching { it() } }
    }
}
