package dev.lelonio.square.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import dev.lelonio.square.R
import dev.lelonio.square.SquareApplication

/**
 * The soft sound that goes with the app's opening: a rising run of bells in
 * A major that comes to rest in an open chord as the logo's ring comes home,
 * two seconds and a little tail, timed to the picture (see IntroSplash).
 *
 * It is a user-interface sound and treated as one: played on the system's own
 * sound stream, so a phone on silent or vibrate stays silent, and without
 * taking the audio focus, so nothing else is paused for it. It is never played
 * over music that is already going, and not at all if the listener has turned
 * it off. Nothing is loaded in either case.
 *
 * [prepare] is called as the app starts, early, so the sound is decoded by the
 * time the picture begins; [play] is called with the picture. If it is not
 * ready by then it starts as soon as it is, a moment late and not never.
 */
object IntroSound {

    private const val VOLUME = 0.6f

    private val lock = Any()
    private var pool: SoundPool? = null
    private var soundId = 0
    private var loaded = false
    private var asked = false

    /** Starts loading the sound, if it is wanted. Only for a fresh start of the app, not for a screen rebuilt. */
    fun prepare(context: Context) {
        val app = context.applicationContext
        val preferences = (app as? SquareApplication)?.preferences ?: return
        if (!preferences.introSound.value) return
        val audio = app.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // Never over a song that is already playing.
        if (audio?.isMusicActive == true) return

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val sounds = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(attributes)
            .build()
        synchronized(lock) {
            releaseLocked()
            pool = sounds
            loaded = false
            asked = false
        }
        sounds.setOnLoadCompleteListener { loadedPool, id, status ->
            if (status != 0) return@setOnLoadCompleteListener
            synchronized(lock) {
                if (pool !== loadedPool) return@setOnLoadCompleteListener
                loaded = true
                if (asked) startLocked(loadedPool, id)
            }
        }
        val id = sounds.load(app, R.raw.intro_chime, 1)
        synchronized(lock) { if (pool === sounds) soundId = id }
    }

    /** Plays it, now if it is ready and as soon as it is if not. Nothing if it was not prepared. */
    fun play() {
        synchronized(lock) {
            val sounds = pool ?: return
            asked = true
            if (loaded) startLocked(sounds, soundId)
        }
    }

    private fun startLocked(sounds: SoundPool, id: Int) {
        asked = false
        sounds.play(id, VOLUME, VOLUME, 1, 0, 1f)
        // Let go of it once it has finished.
        Handler(Looper.getMainLooper()).postDelayed({ synchronized(lock) { releaseLocked() } }, 3500L)
    }

    private fun releaseLocked() {
        pool?.release()
        pool = null
        loaded = false
        asked = false
    }
}
